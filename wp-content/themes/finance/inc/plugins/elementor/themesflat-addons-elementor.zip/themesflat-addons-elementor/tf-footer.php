		</div><!-- /.row -->
    </div><!-- /.container -->
</div><!-- #content -->
<?php do_action( 'tf_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html> 